#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QDir>
#include <QFileInfo>
#include <QDateTime>
#include <QRegularExpression>
#include <QDesktopServices>
#include <QUrl>
#include <QMessageBox>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
    , m_process(new QProcess(this))
    , m_originalFileSize(0)
    , m_detectedUpxIndex(-1)
    , m_pendingAction(None)
{
    ui->setupUi(this);
    
    // 启用拖放功能
    setAcceptDrops(true);
    
    connect(m_process, SIGNAL(finished(int, QProcess::ExitStatus)),
            this, SLOT(processFinished(int, QProcess::ExitStatus)));
    connect(m_process, SIGNAL(readyReadStandardOutput()),
            this, SLOT(processReadyReadStandardOutput()));
    connect(m_process, SIGNAL(readyReadStandardError()),
            this, SLOT(processReadyReadStandardError()));
    
    // 使用 Qt 自动连接机制，槽函数命名格式为 on_<objectName>_<signal>
    
    initUpxVersions();
    checkUpxExists();
    updateStatusDisplay();
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::initUpxVersions()
{
    m_upxVersions << "UPX 1.25 (Win32)"
                  << "UPX 2.3 (Win32)"
                  << "UPX 4.2.2 (Win32)"
                  << "UPX 4.2.2 (Win64)"
                  << "UPX 5.1.1 (Win32)"
                  << "UPX 5.1.1 (Win64)"
                  << "UPX 5.2.0 (Win32)"
                  << "UPX 5.2.0 (Win64)";
    
    m_upxPaths << "upx-1.25-win32.exe"
               << "upx-2.3-win32.exe"
               << "upx-4.2.2-win32.exe"
               << "upx-4.2.2-win64.exe"
               << "upx-5.1.1-win32.exe"
               << "upx-5.1.1-win64.exe"
               << "upx-5.2.0-win32.exe"
               << "upx-5.2.0-win64.exe";
    
    ui->cmbUpxVersion->addItems(m_upxVersions);
}

void MainWindow::checkUpxExists()
{
    QString appDir = QCoreApplication::applicationDirPath();
    
    for (int i = 0; i < m_upxPaths.size(); ++i) {
        QString fullPath = appDir + "/" + m_upxPaths[i];
        bool exists = QFile::exists(fullPath);
        ui->cmbUpxVersion->setItemData(i, exists, Qt::UserRole);
        
        if (!exists) {
            ui->cmbUpxVersion->setItemText(i, m_upxVersions[i] + " [缺失]");
        }
    }
}

void MainWindow::updateStatusDisplay()
{
    if (m_currentFile.isEmpty()) {
        ui->lblFileInfo->setText("未选择文件");
        ui->lblStatus->setText("状态: 等待选择文件");
        ui->btnExecute->setEnabled(false);
        ui->btnCheckStatus->setEnabled(false);
        clearCompressRatio();
        return;
    }
    
    QFileInfo fileInfo(m_currentFile);
    QString info = QString("文件: %1\n大小: %2 字节\n修改时间: %3")
                   .arg(fileInfo.fileName())
                   .arg(fileInfo.size())
                   .arg(fileInfo.lastModified().toString("yyyy-MM-dd HH:mm:ss"));
    ui->lblFileInfo->setText(info);
    
    ui->btnExecute->setEnabled(true);
    ui->btnCheckStatus->setEnabled(true);
}

QString MainWindow::getSelectedUpxPath()
{
    int index = ui->cmbUpxVersion->currentIndex();
    if (index >= 0 && index < m_upxPaths.size()) {
        QString appDir = QCoreApplication::applicationDirPath();
        return appDir + "/" + m_upxPaths[index];
    }
    return "";
}

QString MainWindow::getCurrentAction()
{
    if (ui->rdoCompress->isChecked()) {
        return ui->chkUltraBrute->isChecked() ? "压缩 (Ultra Brute)" : "压缩";
    } else {
        return "解压";
    }
}

bool MainWindow::containsSpecialCharacters(const QString &path)
{
    QRegularExpression chinesePattern("[\\u4e00-\\u9fa5]");
    QRegularExpression specialPattern("[~!@#$%^&*()+|{}';,<>`]");
    
    return chinesePattern.match(path).hasMatch() || specialPattern.match(path).hasMatch();
}

void MainWindow::on_btnSelectFile_clicked()
{
    QString filter = "可执行文件 (*.exe *.dll *.com *.sys *.scr *.ocx *.acm *.ax *.bpl *.dpl)";
    QString filePath = QFileDialog::getOpenFileName(this, "选择要处理的文件", "", filter);
    
    if (!filePath.isEmpty()) {
        if (containsSpecialCharacters(filePath)) {
            QMessageBox::warning(this, "警告", "文件路径中包含中文或特殊字符，可能导致UPX处理失败。\n建议将文件移动到纯英文路径下。");
        }
        
        m_currentFile = filePath;
        ui->txtFilePath->setText(filePath);
        updateStatusDisplay();
        ui->txtOutput->clear();
        m_detectedUpxIndex = -1;
        
        // 自动检测文件状态和UPX版本
        ui->lblStatus->setText("状态: 正在自动检测UPX版本...");
        ui->btnExecute->setEnabled(false);
        ui->btnCheckStatus->setEnabled(false);
        autoDetectUpxVersion(filePath);
    }
}

void MainWindow::on_btnCheckStatus_clicked()
{
    if (m_currentFile.isEmpty()) return;
    
    QString upxPath = getSelectedUpxPath();
    if (!QFile::exists(upxPath)) {
        QMessageBox::warning(this, "错误", "UPX程序不存在: " + upxPath);
        return;
    }
    
    ui->txtOutput->clear();
    ui->lblStatus->setText("状态: 正在检测文件状态...");
    ui->btnExecute->setEnabled(false);
    ui->btnCheckStatus->setEnabled(false);
    
    QStringList args;
    args << "-t" << m_currentFile;
    
    m_process->start(upxPath, args);
}

void MainWindow::on_btnExecute_clicked()
{
    if (m_currentFile.isEmpty()) return;
    
    QString upxPath = getSelectedUpxPath();
    if (!QFile::exists(upxPath)) {
        QMessageBox::warning(this, "错误", "UPX程序不存在: " + upxPath);
        return;
    }
    
    m_selectedUpxPath = upxPath;
    ui->txtOutput->clear();
    ui->btnExecute->setEnabled(false);
    ui->btnCheckStatus->setEnabled(false);
    
    if (ui->rdoCompress->isChecked()) {
        // 记录原始文件大小用于计算压缩率
        QFileInfo fileInfo(m_currentFile);
        m_originalFileSize = fileInfo.size();
        clearCompressRatio();
        // 压缩前先检测文件是否已被UPX压缩
        ui->lblStatus->setText("状态: 正在检测文件是否已被UPX压缩...");
        m_pendingAction = CheckThenCompress;
        QStringList args;
        args << "-t" << m_currentFile;
        m_process->start(upxPath, args);
    } else {
        // 直接执行解压
        ui->lblStatus->setText(QString("状态: 正在%1...").arg(getCurrentAction()));
        m_pendingAction = ExecuteDecompress;
        QStringList args;
        args << "-d" << m_currentFile;
        m_process->start(upxPath, args);
    }
}

void MainWindow::on_cmbUpxVersion_currentIndexChanged(int index)
{
    // 根据选择的版本决定是否使用Ultra Brute模式
    // 版本1、2（UPX 1.25、2.3）：普通压缩
    // 版本3-6（UPX 4.2.2、5.1.1、5.2.0）：强力压缩
    if (index == 0 || index == 1) {
        ui->chkUltraBrute->setChecked(false);
        ui->chkUltraBrute->setEnabled(false);
    } else {
        ui->chkUltraBrute->setChecked(true);
        ui->chkUltraBrute->setEnabled(false);
    }
}

void MainWindow::on_rdoCompress_toggled(bool checked)
{
    // 只有在选择压缩模式时才启用Ultra Brute复选框
    // 但根据批处理逻辑，版本1、2不支持Ultra Brute，所以保持禁用
    int index = ui->cmbUpxVersion->currentIndex();
    if (checked && (index == 0 || index == 1)) {
        ui->chkUltraBrute->setChecked(false);
        ui->chkUltraBrute->setEnabled(false);
    } else if (checked) {
        ui->chkUltraBrute->setChecked(true);
        ui->chkUltraBrute->setEnabled(false);
    } else {
        ui->chkUltraBrute->setEnabled(false);
    }
}

void MainWindow::on_rdoDecompress_toggled(bool checked)
{
    Q_UNUSED(checked);
}

void MainWindow::on_chkUltraBrute_stateChanged(int arg1)
{
    Q_UNUSED(arg1);
}

void MainWindow::processFinished(int exitCode, QProcess::ExitStatus exitStatus)
{
    // 处理自动检测UPX版本
    if (m_pendingAction == AutoDetectVersion) {
        QString appDir = QCoreApplication::applicationDirPath();
        
        if (exitStatus == QProcess::NormalExit && exitCode == 0) {
            // 找到能识别该文件的UPX版本
            ui->cmbUpxVersion->setCurrentIndex(m_detectedUpxIndex);
            
            QFileInfo fileInfo(m_currentFile);
            ui->txtOutput->append(QString("\n检测结果: 文件已被UPX压缩！\n"));
            ui->txtOutput->append(QString("识别的UPX版本: %1\n").arg(m_upxVersions[m_detectedUpxIndex]));
            ui->txtOutput->append(QString("压缩工具: %1\n").arg(m_upxPaths[m_detectedUpxIndex]));
            
            ui->lblStatus->setText("状态: 文件已被UPX压缩，已自动选择正确的版本");
            ui->rdoDecompress->setChecked(true);  // 自动切换到解压模式
            ui->btnExecute->setEnabled(true);
            ui->btnCheckStatus->setEnabled(true);
            m_pendingAction = None;
            
            QMessageBox::information(this, "检测完成", 
                QString("文件已被UPX压缩！\n\n"
                        "识别的UPX版本: %1\n"
                        "已自动选择正确的版本进行解压。").arg(m_upxVersions[m_detectedUpxIndex]));
        } else {
            // 当前版本无法识别，尝试下一个版本
            m_detectedUpxIndex++;
            
            if (m_detectedUpxIndex < m_upxPaths.size()) {
                // 尝试下一个版本
                QString upxPath = appDir + "/" + m_upxPaths[m_detectedUpxIndex];
                
                if (QFile::exists(upxPath)) {
                    ui->txtOutput->append(QString("版本 %1 无法识别，尝试下一个版本...\n").arg(m_upxPaths[m_detectedUpxIndex - 1]));
                    
                    QStringList args;
                    args << "-t" << m_currentFile;
                    m_process->start(upxPath, args);
                    return;
                } else {
                    // 版本不存在，跳过
                    m_detectedUpxIndex++;
                    if (m_detectedUpxIndex < m_upxPaths.size()) {
                        upxPath = appDir + "/" + m_upxPaths[m_detectedUpxIndex];
                        QStringList args;
                        args << "-t" << m_currentFile;
                        m_process->start(upxPath, args);
                        return;
                    }
                }
            }
            
            // 所有版本都无法识别，文件未被UPX压缩或使用了不支持的版本
            ui->txtOutput->append("\n检测结果: 文件未被UPX压缩或使用了不支持的版本。\n");
            ui->txtOutput->append("提示: 可以直接进行压缩操作。\n");
            ui->lblStatus->setText("状态: 文件未被UPX压缩，可直接压缩");
            ui->rdoCompress->setChecked(true);  // 自动切换到压缩模式
            ui->btnExecute->setEnabled(true);
            ui->btnCheckStatus->setEnabled(true);
            m_pendingAction = None;
            
            QMessageBox::information(this, "检测完成", 
                "文件未被UPX压缩或使用了不支持的版本。\n\n可以切换到\"压缩\"模式进行压缩操作。");
        }
        return;
    }
    
    // 处理压缩前的预检测结果
    if (m_pendingAction == CheckThenCompress) {
        if (exitStatus == QProcess::NormalExit && exitCode == 0) {
            // 文件已被UPX压缩
            ui->txtOutput->append("\n检测结果: 文件已被UPX压缩，无法重复压缩。");
            ui->txtOutput->append("提示: 请切换到\"解压\"模式后再执行。\n");
            ui->lblStatus->setText("状态: 文件已被UPX压缩，请使用解压功能");
            QMessageBox::information(this, "提示", "该文件已被UPX压缩，无法重复压缩。\n请切换到\"解压\"模式后再执行。");
            ui->btnExecute->setEnabled(true);
            ui->btnCheckStatus->setEnabled(true);
            m_pendingAction = None;
            return;
        }
        
        // 文件未被压缩，继续执行压缩
        ui->txtOutput->append("\n检测结果: 文件未被UPX压缩，开始执行压缩...\n");
        ui->lblStatus->setText(QString("状态: 正在%1...").arg(getCurrentAction()));
        m_pendingAction = ExecuteCompress;
        
        QStringList args;
        args << "-f";
        if (ui->chkUltraBrute->isChecked()) {
            args << "--ultra-brute";
        }
        args << m_currentFile;
        
        m_process->start(m_selectedUpxPath, args);
        return;
    }
    
    // 正常的执行结果处理
    QString statusText;
    QString resultText;
    
    if (exitStatus == QProcess::NormalExit) {
        if (exitCode == 0) {
            statusText = QString("状态: %1 成功").arg(getCurrentAction());
            resultText = "\n=== 操作成功完成 ===";
        } else {
            statusText = QString("状态: %1 失败 (错误码: %2)").arg(getCurrentAction()).arg(exitCode);
            resultText = "\n=== 操作失败 ===";
        }
    } else {
        statusText = "状态: 进程异常终止";
        resultText = "\n=== 进程异常终止 ===";
    }
    
    ui->txtOutput->append(resultText);
    ui->lblStatus->setText(statusText);
    ui->btnExecute->setEnabled(true);
    ui->btnCheckStatus->setEnabled(true);
    
    if (exitCode == 0 && m_pendingAction == ExecuteCompress) {
        QFileInfo fileInfo(m_currentFile);
        updateStatusDisplay();
        updateCompressRatio();
    }
    
    m_pendingAction = None;
}

void MainWindow::processReadyReadStandardOutput()
{
    QString output = m_process->readAllStandardOutput();
    ui->txtOutput->append(output);
}

void MainWindow::processReadyReadStandardError()
{
    QString error = m_process->readAllStandardError();
    ui->txtOutput->append("错误: " + error);
}

void MainWindow::on_actionOfficialWebsite_triggered()
{
    QDesktopServices::openUrl(QUrl("https://github.com/upx/upx"));
}

void MainWindow::on_actionReleases_triggered()
{
    QDesktopServices::openUrl(QUrl("https://github.com/upx/upx/releases"));
}

void MainWindow::on_actionGroupInfo_triggered()
{
    QString groupText =
        "科技之星1群：669812887\n"
        "科技之星总群：561116458\n"
        "新人报道群：1032931117\n\n"
        "注：进群后请群内冒泡或者数字“1”避免再出现前段时间因经济纠纷引起的事件，\n"
        "造成群内部分群友损失被骗！\n"
        "有任何问题请直接群内艾特@管理员或者群主，避免上当受骗，\n"
        "所因不重视此说明，被骗与本群主及管理员无任何关联。";

    QMessageBox::information(this, "群号信息", groupText);
}

void MainWindow::on_actionAbout_triggered()
{
    QString aboutText =
        "UPX GUI - 可视化压缩/解压工具\n\n"
        "版本: 1.0\n"
        "基于 Qt 6.5.3 开发\n\n"
        "支持的 UPX 版本:\n"
        "  - UPX 1.25 (Win32)\n"
        "  - UPX 2.3 (Win32)\n"
        "  - UPX 4.2.2 (Win32/Win64)\n"
        "  - UPX 5.1.1 (Win32/Win64)\n"
        "  - UPX 5.2.0 (Win32/Win64)\n\n"
        "功能:\n"
        "  - 文件压缩/解压\n"
        "  - Ultra Brute 强力压缩模式\n"
        "  - 文件状态检测\n\n"
        "官方网站: https://github.com/upx/upx\n\n"
        "========================================\n"
        "        软件许可与版权声明\n"
        "========================================\n"
        "版权归属：本软件著作权归开发者所有，受《中华人民共和国著作权法》及国际版权条约保护。\n"
        "禁止篡改：严禁逆向工程、反编译、篡改版权信息、修改程序逻辑并二次发布。\n"
        "合法使用：使用需遵守国家法律法规，违规使用产生的法律责任由用户自行承担。\n"
        "免责声明：软件按现状提供，无任何明示或默示担保，开发者不承担使用过程中产生的各类损失。\n\n"
        "请遵守法律法规，尊重知识产权";

    QMessageBox::about(this, "关于 UPX GUI", aboutText);
}

void MainWindow::updateCompressRatio()
{
    if (m_originalFileSize <= 0 || m_currentFile.isEmpty()) {
        clearCompressRatio();
        return;
    }
    
    QFileInfo fileInfo(m_currentFile);
    qint64 compressedSize = fileInfo.size();
    
    if (compressedSize > 0 && m_originalFileSize > 0) {
        double ratio = (1.0 - (double)compressedSize / (double)m_originalFileSize) * 100.0;
        ui->lblCompressRatio->setText(QString("压缩率: %1%").arg(QString::number(ratio, 'f', 1)));
    } else {
        clearCompressRatio();
    }
}

void MainWindow::clearCompressRatio()
{
    ui->lblCompressRatio->setText("压缩率: --");
}

void MainWindow::autoDetectUpxVersion(const QString &filePath)
{
    // 从第一个UPX版本开始检测
    m_detectedUpxIndex = 0;
    m_pendingAction = AutoDetectVersion;
    
    QString appDir = QCoreApplication::applicationDirPath();
    QString upxPath = appDir + "/" + m_upxPaths[0];
    
    if (!QFile::exists(upxPath)) {
        // 找到第一个存在的UPX版本
        for (int i = 1; i < m_upxPaths.size(); ++i) {
            upxPath = appDir + "/" + m_upxPaths[i];
            if (QFile::exists(upxPath)) {
                m_detectedUpxIndex = i;
                break;
            }
        }
    }
    
    ui->txtOutput->append("正在自动检测UPX版本，请稍候...\n");
    
    // 开始第一个版本的检测
    upxPath = appDir + "/" + m_upxPaths[m_detectedUpxIndex];
    QStringList args;
    args << "-t" << filePath;
    m_process->start(upxPath, args);
}

void MainWindow::dragEnterEvent(QDragEnterEvent *event)
{
    if (event->mimeData()->hasUrls()) {
        event->acceptProposedAction();
    }
}

void MainWindow::dropEvent(QDropEvent *event)
{
    const QMimeData *mimeData = event->mimeData();
    
    if (mimeData->hasUrls()) {
        QList<QUrl> urlList = mimeData->urls();
        
        if (!urlList.isEmpty()) {
            QString filePath = urlList.at(0).toLocalFile();
            
            // 检查文件是否存在
            QFileInfo fileInfo(filePath);
            
            if (fileInfo.exists() && fileInfo.isFile()) {
                // 检查是否为可执行文件类型
                QString suffix = fileInfo.suffix().toLower();
                QStringList validExtensions = {"exe", "dll", "com", "sys", "scr", "ocx", "acm", "ax", "bpl", "dpl"};
                
                if (validExtensions.contains(suffix) || suffix.isEmpty()) {
                    // 处理文件路径
                    if (containsSpecialCharacters(filePath)) {
                        QMessageBox::warning(this, "警告", "文件路径中包含中文或特殊字符，可能导致UPX处理失败。\n建议将文件移动到纯英文路径下。");
                    }
                    
                    m_currentFile = filePath;
                    ui->txtFilePath->setText(filePath);
                    updateStatusDisplay();
                    ui->txtOutput->clear();
                    m_detectedUpxIndex = -1;
                    
                    ui->lblStatus->setText("状态: 已拖放文件 " + fileInfo.fileName() + "，正在检测UPX版本...");
                    ui->btnExecute->setEnabled(false);
                    ui->btnCheckStatus->setEnabled(false);
                    
                    // 自动检测文件状态和UPX版本
                    autoDetectUpxVersion(filePath);
                } else {
                    QMessageBox::warning(this, "警告", "不支持的文件类型: ." + suffix + "\n请选择可执行文件（exe、dll等）。");
                }
            } else {
                QMessageBox::warning(this, "警告", "文件不存在或路径无效。");
            }
        }
    }
    
    event->acceptProposedAction();
}
