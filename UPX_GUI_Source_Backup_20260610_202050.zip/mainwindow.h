#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QProcess>
#include <QFileDialog>
#include <QMessageBox>
#include <QStringList>
#include <QTimer>
#include <QDragEnterEvent>
#include <QMimeData>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

protected:
    void dragEnterEvent(QDragEnterEvent *event) override;
    void dropEvent(QDropEvent *event) override;

private slots:
    void on_btnSelectFile_clicked();
    void on_btnExecute_clicked();
    void on_btnCheckStatus_clicked();
    void on_cmbUpxVersion_currentIndexChanged(int index);
    void on_rdoCompress_toggled(bool checked);
    void on_rdoDecompress_toggled(bool checked);
    void on_chkUltraBrute_stateChanged(int arg1);
    void on_actionOpenFile_triggered();
    void on_actionExit_triggered();
    void on_actionUPXWebsite_triggered();
    void on_actionUpdateWebsite_triggered();
    void on_actionFeedback_triggered();
    void on_actionAbout_triggered();
    
    void processFinished(int exitCode, QProcess::ExitStatus exitStatus);
    void processReadyReadStandardOutput();
    void processReadyReadStandardError();

private:
    Ui::MainWindow *ui;
    QProcess *m_process;
    QString m_currentFile;
    QStringList m_upxVersions;
    QStringList m_upxPaths;
    qint64 m_originalFileSize;
    int m_detectedUpxIndex;  // 自动检测到的UPX版本索引
    
    enum PendingAction { None, CheckThenCompress, ExecuteCompress, ExecuteDecompress, AutoDetectVersion };
    PendingAction m_pendingAction;
    QString m_selectedUpxPath;
    
    void initUpxVersions();
    void updateStatusDisplay();
    void checkUpxExists();
    QString getSelectedUpxPath();
    QString getCurrentAction();
    bool containsSpecialCharacters(const QString &path);
    void updateCompressRatio();
    void clearCompressRatio();
    void autoDetectUpxVersion(const QString &filePath);
};

#endif // MAINWINDOW_H
