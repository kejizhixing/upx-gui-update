#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QDesktopServices>
#include <QUrl>
#include <QDir>
#include <QFileInfo>
#include <QDateTime>
#include <QRegularExpression>
#include <QStandardPaths>
#include <QApplication>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
    , m_process(new QProcess(this))
    , m_originalFileSize(0)
    , m_detectedUpxIndex(-1)
    , m_pendingAction(None)
{
    ui->setupUi(this);
    
    // 启用拖放功能
    setAcceptDrops(true);
    
    connect(m_process, SIGNAL(finished(int, QProcess::ExitStatus)),
            this, SLOT(processFinished(int, QProcess::ExitStatus)));
    connect(m_process, SIGNAL(readyReadStandardOutput()),
            this, SLOT(processReadyReadStandardOutput()));
    connect(m_process, SIGNAL(readyReadStandardError()),
            this, SLOT(processReadyReadStandardError()));
    
    initUpxVersions();
    checkUpxExists();
    
    ui->btnExecute->setEnabled(false);
    ui->btnCheckStatus->setEnabled(false);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::initUpxVersions()
{
    m_upxVersions.clear();
    m_upxPaths.clear();
    
    // 添加 UPX 版本
    m_upxVersions << "UPX 1.25 (Win32)";
    m_upxPaths << "upx-1.25-win32.exe";
    
    m_upxVersions << "UPX 2.3 (Win32)";
    m_upxPaths << "upx-2.03-win32.exe";
    
    m_upxVersions << "UPX 4.2.2 (Win32)";
    m_upxPaths << "upx-4.2.2-win32.exe";
    
    m_upxVersions << "UPX 4.2.2 (Win64)";
    m_upxPaths << "upx-4.2.2-win64.exe";
    
    m_upxVersions << "UPX 5.1.1 (Win32)";
    m_upxPaths << "upx-5.1.1-win32.exe";
    
    m_upxVersions << "UPX 5.1.1 (Win64)";
    m_upxPaths << "upx-5.1.1-win64.exe";
    
    m_upxVersions << "UPX 5.2.0 (Win32)";
    m_upxPaths << "upx-5.2.0-win32.exe";
    
    m_upxVersions << "UPX 5.2.0 (Win64)";
    m_upxPaths << "upx-5.2.0-win64.exe";
    
    ui->cmbUpxVersion->addItems(m_upxVersions);
}

void MainWindow::checkUpxExists()
{
    QString appDir = QCoreApplication::applicationDirPath();
    int availableIndex = -1;
    
    for (int i = 0; i < m_upxPaths.size(); ++i) {
        QString upxPath = appDir + "/" + m_upxPaths[i];
        if (QFile::exists(upxPath)) {
            if (availableIndex == -1) {
                availableIndex = i;
            }
        }
    }
    
    if (availableIndex != -1) {
        ui->cmbUpxVersion->setCurrentIndex(availableIndex);
    }
}

void MainWindow::updateStatusDisplay()
{
    if (m_currentFile.isEmpty()) {
        ui->lblFileInfo->setText("未选择文件");
        ui->btnExecute->setEnabled(false);
        ui->btnCheckStatus->setEnabled(false);
        ui->lblStatus->setText("状态：等待选择文件");
        clearCompressRatio();
        return;
    }
    
    QFileInfo fileInfo(m_currentFile);
    QString info = QString("文件: %1\n大小: %2 字节\n修改时间: %3")
        .arg(fileInfo.fileName())
        .arg(fileInfo.size())
        .arg(fileInfo.lastModified().toString("yyyy-MM-dd HH:mm:ss"));
    
    ui->lblFileInfo->setText(info);
    ui->btnExecute->setEnabled(true);
    ui->btnCheckStatus->setEnabled(true);
    ui->lblStatus->setText("状态：就绪");
    clearCompressRatio();
}

void MainWindow::on_btnSelectFile_clicked()
{
    QString filter = "可执行文件 (*.exe *.dll *.com *.sys *.scr *.ocx *.acm *.ax *.bpl *.dpl)";
    QString filePath = QFileDialog::getOpenFileName(this, "选择要处理的文件", "", filter);
    
    if (!filePath.isEmpty()) {
        if (containsSpecialCharacters(filePath)) {
            QMessageBox::warning(this, "警告", "文件路径中包含中文或特殊字符，可能导致 UPX 处理失败。\n建议将文件移动到纯英文路径下。");
        }
        
        m_currentFile = filePath;
        ui->txtFilePath->setText(filePath);
        updateStatusDisplay();
        ui->txtOutput->clear();
        m_detectedUpxIndex = -1;
        
        // 自动检测文件状态和 UPX 版本
        ui->lblStatus->setText("状态：正在自动检测 UPX 版本...");
        ui->btnExecute->setEnabled(false);
        ui->btnCheckStatus->setEnabled(false);
        autoDetectUpxVersion(filePath);
    }
}

void MainWindow::on_cmbUpxVersion_currentIndexChanged(int index)
{
    Q_UNUSED(index);
    // 版本切换时更新 Ultra Brute 复选框状态
    int currentIndex = ui->cmbUpxVersion->currentIndex();
    
    // UPX 1.25 和 2.3 不支持 Ultra Brute
    if (currentIndex == 0 || currentIndex == 1) {
        ui->chkUltraBrute->setChecked(false);
        ui->chkUltraBrute->setEnabled(false);
    } else {
        ui->chkUltraBrute->setChecked(true);
        ui->chkUltraBrute->setEnabled(true);
    }
}

void MainWindow::on_rdoCompress_toggled(bool checked)
{
    if (checked) {
        int currentIndex = ui->cmbUpxVersion->currentIndex();
        if (currentIndex > 1) {
            ui->chkUltraBrute->setChecked(true);
            ui->chkUltraBrute->setEnabled(true);
        }
    }
}

void MainWindow::on_rdoDecompress_toggled(bool checked)
{
    Q_UNUSED(checked);
    ui->chkUltraBrute->setChecked(false);
    ui->chkUltraBrute->setEnabled(false);
}

void MainWindow::on_btnCheckStatus_clicked()
{
    if (m_currentFile.isEmpty()) {
        QMessageBox::warning(this, "警告", "请先选择要检测的文件。");
        return;
    }
    
    ui->txtOutput->clear();
    ui->lblStatus->setText("状态：正在检测文件状态...");
    ui->btnExecute->setEnabled(false);
    
    QString upxPath = getSelectedUpxPath();
    if (upxPath.isEmpty()) {
        QMessageBox::critical(this, "错误", "未找到 UPX 程序，请确保 UPX 可执行文件存在于程序目录中。");
        ui->lblStatus->setText("状态：错误 - 未找到 UPX 程序");
        ui->btnExecute->setEnabled(true);
        return;
    }
    
    QStringList args;
    args << "-t" << m_currentFile;
    
    ui->txtOutput->append("正在检测文件...\n");
    m_process->start(upxPath, args);
}

void MainWindow::on_btnExecute_clicked()
{
    if (m_currentFile.isEmpty()) {
        QMessageBox::warning(this, "警告", "请先选择要处理的文件。");
        return;
    }
    
    QString upxPath = getSelectedUpxPath();
    if (upxPath.isEmpty()) {
        QMessageBox::critical(this, "错误", "未找到 UPX 程序，请确保 UPX 可执行文件存在于程序目录中。");
        ui->lblStatus->setText("状态：错误 - 未找到 UPX 程序");
        return;
    }
    
    m_selectedUpxPath = upxPath;
    ui->txtOutput->clear();
    
    if (ui->rdoDecompress->isChecked()) {
        // 解压操作
        ui->lblStatus->setText("状态：正在解压...");
        QStringList args;
        args << "-d" << m_currentFile;
        m_process->start(upxPath, args);
    } else {
        // 压缩操作 - 先检测文件是否已被压缩
        ui->txtOutput->append("正在检测文件是否已被 UPX 压缩...\n");
        m_pendingAction = CheckThenCompress;
        
        QStringList args;
        args << "-t" << m_currentFile;
        m_process->start(upxPath, args);
    }
}

void MainWindow::on_chkUltraBrute_stateChanged(int arg1)
{
    Q_UNUSED(arg1);
    // Ultra Brute 模式切换
}

void MainWindow::processFinished(int exitCode, QProcess::ExitStatus exitStatus)
{
    // 处理自动检测 UPX 版本
    if (m_pendingAction == AutoDetectVersion) {
        QString appDir = QCoreApplication::applicationDirPath();
        
        if (exitStatus == QProcess::NormalExit && exitCode == 0) {
            // 找到能识别该文件的 UPX 版本
            ui->cmbUpxVersion->setCurrentIndex(m_detectedUpxIndex);
            
            QFileInfo fileInfo(m_currentFile);
            ui->txtOutput->append(QString("\n检测结果：文件已被 UPX 压缩！\n"));
            ui->txtOutput->append(QString("识别的 UPX 版本：%1\n").arg(m_upxVersions[m_detectedUpxIndex]));
            ui->txtOutput->append(QString("压缩工具：%1\n").arg(m_upxPaths[m_detectedUpxIndex]));
            
            ui->lblStatus->setText("状态：文件已被 UPX 压缩，已自动选择正确的版本");
            ui->rdoDecompress->setChecked(true);  // 自动切换到解压模式
            ui->btnExecute->setEnabled(true);
            ui->btnCheckStatus->setEnabled(true);
            m_pendingAction = None;
            
            QMessageBox::information(this, "检测完成", 
                QString("文件已被 UPX 压缩！\n\n"
                        "识别的 UPX 版本：%1\n"
                        "已自动选择正确的版本进行解压。").arg(m_upxVersions[m_detectedUpxIndex]));
        } else {
            // 当前版本无法识别，尝试下一个版本
            m_detectedUpxIndex++;
            
            if (m_detectedUpxIndex < m_upxPaths.size()) {
                // 尝试下一个版本
                QString upxPath = appDir + "/" + m_upxPaths[m_detectedUpxIndex];
                
                if (QFile::exists(upxPath)) {
                    ui->txtOutput->append(QString("版本 %1 无法识别，尝试下一个版本...\n").arg(m_upxPaths[m_detectedUpxIndex - 1]));
                    
                    QStringList args;
                    args << "-t" << m_currentFile;
                    m_process->start(upxPath, args);
                    return;
                } else {
                    // 版本不存在，跳过
                    m_detectedUpxIndex++;
                    if (m_detectedUpxIndex < m_upxPaths.size()) {
                        upxPath = appDir + "/" + m_upxPaths[m_detectedUpxIndex];
                        QStringList args;
                        args << "-t" << m_currentFile;
                        m_process->start(upxPath, args);
                        return;
                    }
                }
            }
            
            // 所有版本都无法识别，文件未被 UPX 压缩或使用了不支持的版本
            ui->txtOutput->append("\n检测结果：文件未被 UPX 压缩或使用了不支持的版本。\n");
            ui->txtOutput->append("提示：可以直接进行压缩操作。\n");
            ui->lblStatus->setText("状态：文件未被 UPX 压缩，可直接压缩");
            ui->rdoCompress->setChecked(true);  // 自动切换到压缩模式
            ui->btnExecute->setEnabled(true);
            ui->btnCheckStatus->setEnabled(true);
            m_pendingAction = None;
            
            QMessageBox::information(this, "检测完成", 
                "文件未被 UPX 压缩或使用了不支持的版本。\n\n可以切换到\"压缩\"模式进行压缩操作。");
        }
        return;
    }
    
    // 处理压缩前的预检测结果
    if (m_pendingAction == CheckThenCompress) {
        if (exitStatus == QProcess::NormalExit && exitCode == 0) {
            // 文件已被 UPX 压缩
            ui->txtOutput->append("\n检测结果：文件已被 UPX 压缩，无法重复压缩！\n");
            ui->txtOutput->append("提示：如果需要重新压缩，请先选择\"解压\"模式。\n");
            ui->lblStatus->setText("状态：文件已被 UPX 压缩");
            ui->btnExecute->setEnabled(true);
            ui->btnCheckStatus->setEnabled(true);
            m_pendingAction = None;
            
            QMessageBox::warning(this, "提示", 
                "文件已被 UPX 压缩，无法重复压缩！\n\n"
                "如需重新压缩，请先选择\"解压\"模式解压文件。");
            return;
        }
        
        // 文件未被压缩，继续执行压缩
        ui->txtOutput->append("\n检测结果：文件未被 UPX 压缩，开始执行压缩...\n");
        ui->lblStatus->setText(QString("状态：正在%1...").arg(getCurrentAction()));
        m_pendingAction = ExecuteCompress;
        
        QStringList args;
        args << "-f";
        if (ui->chkUltraBrute->isChecked()) {
            args << "--ultra-brute";
        }
        args << m_currentFile;
        
        m_process->start(m_selectedUpxPath, args);
        return;
    }
    
    // 正常的执行结果处理
    QString statusText;
    QString resultText;
    
    if (exitStatus == QProcess::NormalExit) {
        if (exitCode == 0) {
            statusText = QString("状态：%1 成功").arg(getCurrentAction());
            resultText = "\n=== 操作成功完成 ===";
        } else {
            statusText = QString("状态：%1 失败 (错误码：%2)").arg(getCurrentAction()).arg(exitCode);
            resultText = "\n=== 操作失败 ===";
        }
    } else {
        statusText = "状态：进程异常终止";
        resultText = "\n=== 进程异常终止 ===";
    }
    
    ui->txtOutput->append(resultText);
    ui->lblStatus->setText(statusText);
    ui->btnExecute->setEnabled(true);
    ui->btnCheckStatus->setEnabled(true);
    
    if (exitCode == 0 && m_pendingAction == ExecuteCompress) {
        QFileInfo fileInfo(m_currentFile);
        updateStatusDisplay();
        updateCompressRatio();
    }
    
    m_pendingAction = None;
}

void MainWindow::processReadyReadStandardOutput()
{
    QString output = m_process->readAllStandardOutput();
    ui->txtOutput->append(output);
}

void MainWindow::processReadyReadStandardError()
{
    QString error = m_process->readAllStandardError();
    ui->txtOutput->append("错误：" + error);
}

void MainWindow::on_actionOpenFile_triggered()
{
    on_btnSelectFile_clicked();
}

void MainWindow::on_actionExit_triggered()
{
    close();
}

void MainWindow::on_actionUPXWebsite_triggered()
{
    QDesktopServices::openUrl(QUrl("https://github.com/upx/upx"));
}

void MainWindow::on_actionUpdateWebsite_triggered()
{
    QDesktopServices::openUrl(QUrl("https://github.com/upx/upx/releases"));
}

void MainWindow::on_actionFeedback_triggered()
{
    QMessageBox::information(this, "留言反馈",
        "欢迎留言反馈！\n\n"
        "请访问 UPX 官方 GitHub 仓库提交问题或建议：\n"
        "https://github.com/upx/upx/issues\n\n"
        "或者加入我们的 QQ 群进行交流：\n"
        "科技之星 1 群：669812887\n"
        "科技之星总群：561116458\n"
        "新人报道群：1032931117");
}

void MainWindow::on_actionAbout_triggered()
{
    QString aboutText =
        "UPX GUI - 可视化压缩/解压工具\n\n"
        "版本：1.0\n"
        "基于 Qt 6.5.3 开发\n\n"
        "支持的 UPX 版本:\n"
        "  - UPX 1.25 (Win32)\n"
        "  - UPX 2.3 (Win32)\n"
        "  - UPX 4.2.2 (Win32/Win64)\n"
        "  - UPX 5.1.1 (Win32/Win64)\n"
        "  - UPX 5.2.0 (Win32/Win64)\n\n"
        "功能:\n"
        "  - 文件压缩/解压\n"
        "  - Ultra Brute 强力压缩模式\n"
        "  - 文件状态检测\n\n"
        "官方网站：https://github.com/upx/upx\n\n"
        "========================================\n"
        "        软件许可与版权声明\n"
        "========================================\n"
        "版权归属：本软件著作权归开发者所有，受《中华人民共和国著作权法》及国际版权条约保护。\n"
        "禁止篡改：严禁逆向工程、反编译、篡改版权信息、修改程序逻辑并二次发布。\n"
        "合法使用：使用需遵守国家法律法规，违规使用产生的法律责任由用户自行承担。\n"
        "免责声明：软件按现状提供，无任何明示或默示担保，开发者不承担使用过程中产生的各类损失。\n\n"
        "🐟—— 请遵守法律法规，尊重知识产权 ——🐟";

    QMessageBox::about(this, "关于软件", aboutText);
}

QString MainWindow::getSelectedUpxPath()
{
    int index = ui->cmbUpxVersion->currentIndex();
    if (index < 0 || index >= m_upxPaths.size()) {
        return "";
    }
    
    QString appDir = QCoreApplication::applicationDirPath();
    return appDir + "/" + m_upxPaths[index];
}

QString MainWindow::getCurrentAction()
{
    if (ui->rdoCompress->isChecked()) {
        return ui->chkUltraBrute->isChecked() ? "压缩 (Ultra Brute)" : "压缩";
    } else {
        return "解压";
    }
}

bool MainWindow::containsSpecialCharacters(const QString &path)
{
    // 检测中文字符
    QRegularExpression chinesePattern("[\\u4e00-\\u9fa5]");
    // 检测特殊字符（排除路径正常字符）
    QRegularExpression specialPattern("[~!@#$%^&*()+|{}';,<>`]");
    
    return chinesePattern.match(path).hasMatch() || specialPattern.match(path).hasMatch();
}

void MainWindow::updateCompressRatio()
{
    if (m_currentFile.isEmpty() || m_originalFileSize <= 0) {
        return;
    }
    
    QFileInfo fileInfo(m_currentFile);
    qint64 newSize = fileInfo.size();
    
    if (newSize > 0) {
        double ratio = (1.0 - (double)newSize / m_originalFileSize) * 100.0;
        ui->lblCompressRatio->setText(QString("压缩率：%1%").arg(ratio, 0, 'f', 1));
    }
}

void MainWindow::clearCompressRatio()
{
    ui->lblCompressRatio->setText("压缩率：--");
}

void MainWindow::autoDetectUpxVersion(const QString &filePath)
{
    // 从第一个 UPX 版本开始检测
    m_detectedUpxIndex = 0;
    m_pendingAction = AutoDetectVersion;
    
    QString appDir = QCoreApplication::applicationDirPath();
    QString upxPath = appDir + "/" + m_upxPaths[0];
    
    if (!QFile::exists(upxPath)) {
        // 找到第一个存在的 UPX 版本
        for (int i = 1; i < m_upxPaths.size(); ++i) {
            upxPath = appDir + "/" + m_upxPaths[i];
            if (QFile::exists(upxPath)) {
                m_detectedUpxIndex = i;
                break;
            }
        }
    }
    
    ui->txtOutput->append("正在自动检测 UPX 版本，请稍候...\n");
    
    // 开始第一个版本的检测
    upxPath = appDir + "/" + m_upxPaths[m_detectedUpxIndex];
    QStringList args;
    args << "-t" << filePath;
    m_process->start(upxPath, args);
}

void MainWindow::dragEnterEvent(QDragEnterEvent *event)
{
    if (event->mimeData()->hasUrls()) {
        event->acceptProposedAction();
    }
}

void MainWindow::dropEvent(QDropEvent *event)
{
    const QMimeData *mimeData = event->mimeData();
    
    if (mimeData->hasUrls()) {
        QList<QUrl> urlList = mimeData->urls();
        
        if (!urlList.isEmpty()) {
            QString filePath = urlList.at(0).toLocalFile();
            
            // 检查文件是否存在
            QFileInfo fileInfo(filePath);
            
            if (fileInfo.exists() && fileInfo.isFile()) {
                // 检查是否为可执行文件类型
                QString suffix = fileInfo.suffix().toLower();
                QStringList validExtensions = {"exe", "dll", "com", "sys", "scr", "ocx", "acm", "ax", "bpl", "dpl"};
                
                if (validExtensions.contains(suffix) || suffix.isEmpty()) {
                    // 处理文件路径
                    if (containsSpecialCharacters(filePath)) {
                        QMessageBox::warning(this, "警告", "文件路径中包含中文或特殊字符，可能导致 UPX 处理失败。\n建议将文件移动到纯英文路径下。");
                    }
                    
                    m_currentFile = filePath;
                    ui->txtFilePath->setText(filePath);
                    updateStatusDisplay();
                    ui->txtOutput->clear();
                    m_detectedUpxIndex = -1;
                    
                    ui->lblStatus->setText("状态：已拖放文件 " + fileInfo.fileName() + "，正在检测 UPX 版本...");
                    ui->btnExecute->setEnabled(false);
                    ui->btnCheckStatus->setEnabled(false);
                    
                    // 自动检测文件状态和 UPX 版本
                    autoDetectUpxVersion(filePath);
                } else {
                    QMessageBox::warning(this, "警告", "不支持的文件类型: ." + suffix + "\n请选择可执行文件（exe、dll 等）。");
                }
            } else {
                QMessageBox::warning(this, "警告", "文件不存在或路径无效。");
            }
        }
    }
    
    event->acceptProposedAction();
}
